import javax.jws.soap.SOAPBinding;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class NewClass {
    ServerSocket myServerSocket;
    boolean ServerOn = true;
    public NewClass() {
        try {
            myServerSocket = new ServerSocket(8082);
        } catch(IOException ioe) {
            System.out.println("Could not create server socket on port 8082. Quitting.");
            System.exit(-1);
        }

        Calendar now = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat(
                "E yyyy.MM.dd 'at' hh:mm:ss a zzz");
        System.out.println("It is now : " + formatter.format(now.getTime()));

        while(ServerOn) {
            try {
                Socket clientSocket = myServerSocket.accept();
                ClientServiceThread cliThread = new ClientServiceThread(clientSocket);
                cliThread.start();
            } catch(IOException ioe) {
                System.out.println("Exception found on accept. Ignoring. Stack Trace :");
                ioe.printStackTrace();
            }
        }
        try {
            myServerSocket.close();
            System.out.println("Server Stopped");
        } catch(Exception ioe) {
            System.out.println("Error Found stopping server socket");
            System.exit(-1);
        }
    }

    public static void main (String[] args) {
        new NewClass();
    }

    class ClientServiceThread extends Thread {
        Socket myClientSocket;
        boolean m_bRunThread = true;

        public ClientServiceThread() {
            super();
        }

        ClientServiceThread(Socket s) {
            myClientSocket = s;
        }

        public void run() {
            BufferedReader in = null;
            PrintWriter out = null;
            System.out.println(
                    "Accepted Client Address - " + myClientSocket.getInetAddress().getHostName());
            try {
                in = new BufferedReader(
                        new InputStreamReader(myClientSocket.getInputStream()));
                out = new PrintWriter(
                        new OutputStreamWriter(myClientSocket.getOutputStream()));

                while (m_bRunThread) {
                    String clientCommand = in.readLine();
                    System.out.println("Client Says :" + clientCommand);

                    if (!ServerOn) {
                        System.out.print("Server has already stopped");
                        out.println("Server has already stopped");
                        out.flush();
                        m_bRunThread = false;
                    }
                    if (clientCommand.contains("details")) {
                        String UserName = clientCommand.substring(0, clientCommand.length() - 8);
                        System.out.println(UserName);
                        String[] details = UserName.split(" ");
                        String fName = details[0];
                        String sName = details[1];
                        String age = details[2];
                        String patientNo = details[3];
                        out.print("From server: " + UserName);
                        out.flush();
                        System.out.println("DETAILS:\nFirst name: " + fName + "\nSeconsd name: " + sName + "\n" + "Age: " + age + "\n" + "PatientNo: " + patientNo + "\n");
                        m_bRunThread = false;
                        System.out.print("Stopping client thread for client : ");
                        sendToDB(fName, sName, age, patientNo);

                    } else if (clientCommand.contains("ecgData")) {
                        System.out.println("Contains ecgData");
                        String ecgData = clientCommand.substring(0, clientCommand.length() - 8);
                        System.out.println(ecgData);
                        out.print("ECG data recieved");
                        out.flush();
                        m_bRunThread = false;
                        System.out.print("Stopping client thread for client : ");
                        sendECGToDB(ecgData);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    in.close();
                    out.close();
                    myClientSocket.close();
                    System.out.println("...Stopped");
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
            }
        }

        public void sendToDB(String fName, String sName, String age, String pNumber) {
            try {
                int theAge = Integer.parseInt(age);
                int thePNumber = Integer.parseInt(pNumber);
                System.out.println("IN SEND TO DB");
                String driver = "com.mysql.jdbc.Driver";
                Class.forName(driver);
                Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
                String query = "insert into employees(patientNo,age,firstName,lastName,ecgData)" + "values(?,?,?,?,?)";
                PreparedStatement preparedStatement = c.prepareStatement(query);
                preparedStatement.setString(3, fName);
                preparedStatement.setString(4, sName);
                preparedStatement.setString(5, "0.3");
                preparedStatement.setInt(2, theAge);
                preparedStatement.setInt(1, thePNumber);
                preparedStatement.execute();
                c.close();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }

        public void sendECGToDB(String ECG) {
            try {
                String ecgdata = ECG;
                System.out.println("IN SEND TO ECG DB");
                System.out.println(ecgdata);
                String patientToUpdate = ecgdata.substring(ecgdata.length() - 5);
                String ecgDataToDB = ecgdata.substring(0, ecgdata.length() - 6);
                ecgDataToDB=("," + ecgDataToDB);
                System.out.println("Patient to be updated: " + patientToUpdate + "\nWith:" + ecgDataToDB);
                String driver = "com.mysql.jdbc.Driver";
                Class.forName(driver);
                Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
                String query = "update Employees SET ecgData = CONCAT(ecgData, (?)) where patientNo = (?);";
                PreparedStatement preparedStatement = c.prepareStatement(query);
                preparedStatement.setString(1, ecgDataToDB);
                preparedStatement.setString(2, patientToUpdate);
                preparedStatement.execute();
                c.close();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }


}