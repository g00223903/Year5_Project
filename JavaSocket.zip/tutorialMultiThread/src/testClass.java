import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Created by patrickshaughnessy on 28/04/2017.
 */
public class testClass {
    public static void main (String[] args){
        String ecgData = "0.2339,0.1781,0.1571,0.1140,0.0734,0.0698,0.1864,0.1977,0.2494,0.2502,99887";
        System.out.println(ecgData);
        String patientToUpdate = ecgData.substring(ecgData.length() - 5);
        String ecgDataToDB = ecgData.substring(0, ecgData.length() - 6);
        System.out.println(patientToUpdate + "\n" + ecgDataToDB);



        /*
         int theAge = Integer.parseInt(age);
                int thePNumber = Integer.parseInt(pNumber);
                System.out.println("IN SEND TO DB");
                String driver = "com.mysql.jdbc.Driver";
                Class.forName(driver);
                Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
                String query = "insert into employees(patientNo,age,firstName,lastName)" + "values(?,?,?,?)";
                PreparedStatement preparedStatement = c.prepareStatement(query);
                preparedStatement.setString(3, fName);
                preparedStatement.setString(4, sName);
                preparedStatement.setInt(2, theAge);
                preparedStatement.setInt(1, thePNumber);
                preparedStatement.execute();
                c.close();
         */
        try {
            System.out.println("IN SEND TO DB");
            String driver = "com.mysql.jdbc.Driver";
            Class.forName(driver);
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
            //update
            //String query = "update employees set ecgData = (?) where patientNo = 33;";

            //append to
            //update Employees SET ecgData = CONCAT(ecgData, (?)) where patientNo = 84;

            String query = "update Employees SET ecgData = CONCAT(ecgData, (?)) where patientNo = 99887;";
            PreparedStatement preparedStatement = c.prepareStatement(query);
            preparedStatement.setString(1, ecgDataToDB);
            //preparedStatement.setString(2, patientToUpdate);
            preparedStatement.execute();
            c.close();
        }



        catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
