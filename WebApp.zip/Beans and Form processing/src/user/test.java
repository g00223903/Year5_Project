package user;

/**
 * Created by patrickshaughnessy on 02/05/2017.
 */
public class test {
    public static void main(String [] args)
    {
        for(int x =0; x < 100; x++){
            System.out.print("\" \""+",");
        }
    }
}
