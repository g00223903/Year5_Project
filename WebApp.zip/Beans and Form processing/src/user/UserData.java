package user;

import java.sql.*;

public class UserData {
    String username;
    String email;
    int age;
    //String ecgData = "1.1,2.2,3.3,4.4,5.5";

    public void setUsername( String value ) {
        try {
            Connection conn = null;
            Statement stmt = null;
            PreparedStatement sqlFind = null;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
            stmt = conn.createStatement();
            sqlFind = conn.prepareStatement("SELECT * FROM Employees WHERE patientNo = ?");
            sqlFind.setString(1, value);
            ResultSet rs = sqlFind.executeQuery();
            System.out.println(rs.toString());
            String ecgData = null;
            while (rs.next()) {
                ecgData = rs.getString("ecgData");

            }

            stmt.close();

            username = ecgData;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void setEmail( String value )
    {
        email = value;
    }
    public void setAge( int value ) {

        age = value;
    }

    public String getUsername() {

        return username; }

    public String getEmail() {

        return email;
    }

    public int getAge() {

        return age;
    }
}
