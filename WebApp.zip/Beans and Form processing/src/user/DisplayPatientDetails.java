package user;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DisplayPatientDetails extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Patients</title></head>");
        //out.println("<meta http-equiv=\"refresh\" content=\"3\">");
        out.println("<body>");
        out.println("<center><h1>All Patients</h1>");
        out.println("<table border=\"1\" width=\"100%\">");
        out.println("<tr>");
        out.println("<th>Patient ID</th>");
        out.println("<th>Age</th>");
        out.println("<th>First Name</th>");
        out.println("<th>Last Name</th>");
        out.println("<th>ECG Data</th>");
        out.println("</tr>");

        Calendar now = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat(
                "E yyyy.MM.dd 'at' hh:mm:ss a zzz");
        System.out.println("It is now : " + formatter.format(now.getTime()));

        String path = getServletContext().getRealPath("WEB-INF/../janet.txt");
        File file = new File(path);

        if (file.createNewFile()){
            System.out.println("File is created!");
        }else{
            System.out.println("File already exists.");
        }

        Connection conn = null;
                Statement stmt = null;
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
                    stmt = conn.createStatement();
                    String orderBy = request.getParameter("sort");
                    if ((orderBy == null) || orderBy.equals("")) {
                        orderBy = "lastName";
                    }

                    String query = "SELECT Employees.patientNo, Employees.age, Employees.firstName, "
                            + "Employees.lastName FROM Employees "
                            + "ORDER BY " + orderBy
                            + ";";
                    ResultSet rs = stmt.executeQuery(query);
                    while (rs.next()) {
                        long patientNo = rs.getLong("patientNo");
                        int age = rs.getInt("Age");
                        String firstName = rs.getString("FirstName");
                        String lastName = rs.getString("LastName");
                //String ecgData = rs.getString("EcgData");
                //prints variables
                out.print("<tr>");
               // out.print("<td><a href=http://localhost:8080/DisplayECG_Details>" + patientNo + "</a></td>");
                        out.print("<td><form method=\"post\" action=\"SaveName.jsp\" class=\"inline\"><input type=\"hidden\" name=\"username\" value="+patientNo+"><button type=\"submit\" name=\"submit_param\" value=\"submit_value\" class=\"link-button\">" + patientNo + "</button></form></td>");
                out.print("<td>" + age          + "</td>");
                out.print("<td>" + firstName    + "</td>");
                out.print("<td>" + lastName     + "</td>");
                out.print("<td><a href=http://localhost:8080/patientdetailsgraph.html> ECG data: TRUE</a></td>");
                out.print("</tr>");
            }
        } catch (SQLException e) {
            out.println("An error occured while retrieving " + "all employees: "
                    + e.toString());
        } catch (ClassNotFoundException e) {
            throw (new ServletException(e.toString()));
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
            }
        }
        out.println("</center>");
        out.println("<table border=\"1\" width=\"100%\">");





        out.print("<FORM METHOD=POST ACTION=\"SaveName.jsp\">");
        out.print("<p>Enter patient no test:</p> <INPUT TYPE=TEXT NAME=username SIZE=20>");
        out.print("<INPUT TYPE=SUBMIT>");
        out.print("</form>");

                out.println("</body>");
        out.println("</html>");
        out.close();
    }

}