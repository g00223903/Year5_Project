package user;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 * Created by patrickshaughnessy on 19/04/2017.
 */
public class DisplayECG_Details extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String getPatientNo = request.getParameter( "patientNo" );
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Patient Details</title></head>");
        out.println("<body>");
        out.println("Patient No: " + getPatientNo + "<br />");
        Connection conn = null;
        Statement stmt = null;
        PreparedStatement sqlFind = null;
        String firstName = null;
        String secondName = null;
        String ecgData = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
            stmt = conn.createStatement();
            sqlFind = conn.prepareStatement("SELECT * FROM Employees WHERE patientNo = ?");
            sqlFind.setString(1, getPatientNo);
            ResultSet rs = sqlFind.executeQuery();
            System.out.println(rs.toString());
            while (rs.next()) {
                firstName = rs.getString("firstName");
                secondName = rs.getString("lastName");
                ecgData = rs.getString("ecgData");

            }

            stmt.close();
            out.println("Patient name: " + firstName + " " + secondName + "<br />");
            out.println(ecgData + "<br />");
            out.println("</body>");
            out.println("</html>");

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
